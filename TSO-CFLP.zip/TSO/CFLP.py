import numpy as np

def read_data(file_path):
    with open(file_path, 'r') as file:
        n, m = map(int, file.readline().split())
        capacities = []
        fixed_costs = []

        for _ in range(n):
            line = file.readline().strip()
            if line:
                capacity, cost = map(float, line.split())
                capacities.append(capacity)
                fixed_costs.append(cost)

        demands = list(map(float, file.readline().split()))
        if len(demands) != m:
            raise ValueError("Number of demands does not match m")

        assignment_costs = []
        for _ in range(n):
            line = file.readline().strip()
            if line:
                row = list(map(float, line.split()))
                if len(row) != m:
                    raise ValueError("One row of assignment costs does not match m")
                assignment_costs.append(row)

    return {
        "n": n,
        "m": m,
        "capacities": capacities,
        "fixed_costs": fixed_costs,
        "demands": demands,
        "assignment_costs": assignment_costs
    }

def cflp(file_path):
    data = read_data(file_path)
    
    n, m = data["n"], data["m"]
    capacities, fixed_costs = data["capacities"], data["fixed_costs"]
    demands, assignment_costs = data["demands"], data["assignment_costs"]
    
    x = np.zeros((n, m))
    y = np.zeros(n)
    remaining_capacity = capacities.copy()
    remaining_demand = demands.copy()
    total_cost = 0

    active_facilities = set(range(n))
    active_customers = set(range(m))

    while active_facilities and active_customers:
        min_cost = float('inf')
        best_facility, best_customer = None, None

        for i in active_facilities:
            for j in active_customers:
                if remaining_demand[j] == 0:
                    continue
                cost = assignment_costs[i][j] + (fixed_costs[i] / demands[j])
                if cost < min_cost:
                    min_cost = cost
                    best_facility, best_customer = i, j

        if best_facility is None or best_customer is None:
            break

        quantity = min(remaining_capacity[best_facility], remaining_demand[best_customer])
        x[best_facility][best_customer] = quantity

        if y[best_facility] == 0:
            y[best_facility] = 1
            total_cost += fixed_costs[best_facility]

        total_cost += assignment_costs[best_facility][best_customer] * quantity
        
        remaining_capacity[best_facility] -= quantity
        remaining_demand[best_customer] -= quantity

        if remaining_capacity[best_facility] <= 1e-6:
            active_facilities.remove(best_facility)
        if remaining_demand[best_customer] <= 1e-6:
            active_customers.remove(best_customer)

    if any(d > 1e-6 for d in remaining_demand):
        raise ValueError("Not all demand could be satisfied.")

    solution = {
        'Opened plants': [i for i in range(n) if y[i] == 1],
        'Assignments': {j: {i: x[i][j] for i in range(n) if x[i][j] > 0} for j in range(m)},
        'Remaining capacity': {i: remaining_capacity[i] for i in range(n)},
        'Remaining demand': {j: remaining_demand[j] for j in range(m)},
        'Total cost': total_cost
    }
    check_feasibility(solution, data)
    return solution

def check_feasibility(solution, data):
    n, m = data["n"], data["m"]
    capacities, demands = data["capacities"], data["demands"]
    
    x = np.zeros((n, m))
    for customer_id, assignments in solution['Assignments'].items():
        for facility_id, quantity in assignments.items():
            x[facility_id][customer_id] = quantity
    
    y = np.zeros(n)
    for facility_id in solution['Opened plants']:
        y[facility_id] = 1
    
    for j in range(m):
        total_assigned = sum(x[i][j] for i in range(n))
        if not np.isclose(total_assigned, demands[j], atol=1e-6):
            print(f"Demand not fully satisfied for customer {j}: assigned={total_assigned}, demand={demands[j]}")
            return False
    
    for i in range(n):
        total_supplied = sum(x[i][j] for j in range(m))
        if total_supplied > capacities[i] + 1e-6:
            print(f"Capacity exceeded at facility {i}: supplied={total_supplied}, capacity={capacities[i]}")
            return False
    
    for i in range(n):
        total_supplied = sum(x[i][j] for j in range(m))
        if y[i] == 0 and total_supplied > 1e-6:
            print(f"Facility {i} is closed but is supplying: {total_supplied}")
            return False
    
    print("Solution is feasible.")
    return True

res = cflp("30-200/30-200-1.dat")
print("Opened plants:", res['Opened plants'])
print("Total cost:", res['Total cost'])

for client, assignments in res['Assignments'].items():
    print(f"Client {client}:")
    for plant, quantity in assignments.items():
        print(f"  - Plant {plant} supplies {quantity}")
